// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 16 (Q4 2021) video 08
//  by Steven Lipton (C)2021, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  The new iOS15 Date formatters
//  For more code, go to http://bit.ly/AppPieGithub

import Foundation

//Formatted dates
// 1984 Mac superbowl commercial
var date = Date(timeIntervalSince1970: 443599200)
date.formatted()
date.formatted(date:.long, time:.omitted)
date.formatted(.dateTime)
date.formatted(.dateTime.year().month().day())
date.formatted(.dateTime.year(.twoDigits).month(.twoDigits).day(.twoDigits))
date.formatted(.dateTime.weekday(.wide).year(.twoDigits).month(.wide).day(.twoDigits))
//Locales
let locale = Locale(identifier: "he_IL")
date.formatted(.dateTime.weekday(.wide).year(.twoDigits).month(.wide).day(.twoDigits).locale(locale))


//Date ranges
let start = date + (6 * 3600) //6:00 AM
let finish = date  + ( 9.5 * 3600) // 9:30 AM
(start..<finish).formatted()


//Parsing dates
let think = "10-14-1998"        //Think Different campaign launch
let strategy = Date.ParseStrategy(format:"\(month:.twoDigits)-\(day: .twoDigits)-\(year: .defaultDigits)", timeZone: TimeZone.current)
if let thinkDate = try? Date(think, strategy: strategy){
    thinkDate.formatted(.dateTime)
}
